Synthetic opaque archival fixture; never compiled or executed.
