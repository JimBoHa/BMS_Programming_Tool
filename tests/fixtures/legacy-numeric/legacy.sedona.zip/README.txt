Synthetic legacy source archive with opaque nonexecuted payloads.
